const API = "/api";
const titles = {
  dashboard: "Dashboard",
  gallery: "Hotel Gallery & Amenities",
  rooms: "Room Management",
  search: "Search Available Rooms",
  book: "Book a Room",
  bookings: "Booking Management"
};

const roomImages = {
  Single: "images/room-single.jpg",
  Double: "images/room-double.jpg",
  Deluxe: "images/room-deluxe.jpg",
  Suite: "images/room-suite.jpg"
};

function getRoomImage(type) {
  return roomImages[type] || "images/room-deluxe.jpg";
}

let roomsCache = [];
let selectedSearchRoomId = null;

function showToast(message, type = "success") {
  const toast = document.getElementById("toast");
  toast.textContent = message;
  toast.className = `toast ${type}`;
  setTimeout(() => toast.classList.add("hidden"), 2800);
}

async function request(url, options = {}) {
  const response = await fetch(url, {
    headers: { "Content-Type": "application/json" },
    ...options
  });
  const body = await response.json();
  if (!response.ok || body.success === false) {
    throw new Error(body.message || "Request failed");
  }
  return body;
}

function formatINR(amount) {
  return `₹${Number(amount || 0).toLocaleString("en-IN")}`;
}

function nightsBetween(checkIn, checkOut) {
  if (!checkIn || !checkOut) return 0;
  const start = new Date(checkIn + "T00:00:00");
  const end = new Date(checkOut + "T00:00:00");
  return Math.round((end - start) / (1000 * 60 * 60 * 24));
}

function switchSection(section) {
  document.querySelectorAll(".page").forEach((page) => page.classList.remove("active"));
  document.getElementById(section).classList.add("active");
  document.querySelectorAll(".nav-btn").forEach((btn) => {
    btn.classList.toggle("active", btn.dataset.section === section);
  });
  document.getElementById("page-title").textContent = titles[section];
}

document.querySelectorAll(".nav-btn").forEach((btn) => {
  btn.addEventListener("click", () => switchSection(btn.dataset.section));
});

async function loadDashboard() {
  const result = await request(`${API}/dashboard/stats`);
  const stats = result.data;
  document.getElementById("stat-total-rooms").textContent = stats.totalRooms;
  document.getElementById("stat-available-rooms").textContent = stats.availableRooms;
  document.getElementById("stat-booked-rooms").textContent = stats.bookedRooms;
  document.getElementById("stat-total-bookings").textContent = stats.totalBookings;
  document.getElementById("stat-cancelled-bookings").textContent = stats.cancelledBookings;
}

async function loadRooms() {
  const q = document.getElementById("room-search").value.trim();
  const type = document.getElementById("room-type-filter").value;
  const params = new URLSearchParams();
  if (q) params.set("q", q);
  if (type) params.set("type", type);

  const result = await request(`${API}/rooms?${params.toString()}`);
  roomsCache = result.data;
  renderRooms(roomsCache);
  fillRoomSelect(roomsCache);
}

function renderRooms(rooms) {
  const tbody = document.getElementById("rooms-table");
  tbody.innerHTML = rooms.map((room) => `
    <tr>
      <td>
        <img src="${getRoomImage(room.room_type)}" alt="${room.room_type}" class="room-thumbnail" />
      </td>
      <td><strong>${room.room_number}</strong></td>
      <td>${room.room_type}</td>
      <td>${formatINR(room.price)}</td>
      <td><span class="status-pill status-${room.status}">${room.status}</span></td>
      <td class="actions">
        <button class="btn small" data-edit="${room.id}">Update</button>
        <button class="btn small danger" data-delete="${room.id}">Delete</button>
      </td>
    </tr>
  `).join("") || `<tr><td colspan="6">No rooms found</td></tr>`;
}

function fillRoomSelect(rooms) {
  const select = document.getElementById("booking-room");
  const current = selectedSearchRoomId || select.value;
  select.innerHTML = rooms.map((room) =>
    `<option value="${room.id}">${room.room_number} - ${room.room_type} (${formatINR(room.price)})</option>`
  ).join("");
  if (current) select.value = current;
  updateBookingSummary();
}

function openRoomModal(room = null) {
  document.getElementById("room-modal").classList.remove("hidden");
  document.getElementById("room-modal-title").textContent = room ? "Update Room" : "Add Room";
  document.getElementById("room-id").value = room ? room.id : "";
  document.getElementById("room-number").value = room ? room.room_number : "";
  document.getElementById("room-type").value = room ? room.room_type : "Single";
  document.getElementById("room-price").value = room ? room.price : "";
  document.getElementById("room-status").value = room ? room.status : "Available";
}

function closeRoomModal() {
  document.getElementById("room-modal").classList.add("hidden");
}

document.getElementById("btn-add-room").addEventListener("click", () => openRoomModal());
document.getElementById("room-cancel").addEventListener("click", closeRoomModal);

document.getElementById("room-form").addEventListener("submit", async (event) => {
  event.preventDefault();
  const id = document.getElementById("room-id").value;
  const payload = {
    room_number: document.getElementById("room-number").value.trim(),
    room_type: document.getElementById("room-type").value,
    price: Number(document.getElementById("room-price").value),
    status: document.getElementById("room-status").value
  };

  try {
    if (id) {
      await request(`${API}/rooms/${id}`, { method: "PUT", body: JSON.stringify(payload) });
      showToast("Room updated successfully");
    } else {
      await request(`${API}/rooms`, { method: "POST", body: JSON.stringify(payload) });
      showToast("Room added successfully");
    }
    closeRoomModal();
    await refreshAll();
  } catch (error) {
    showToast(error.message, "error");
  }
});

document.getElementById("rooms-table").addEventListener("click", async (event) => {
  const editId = event.target.dataset.edit;
  const deleteId = event.target.dataset.delete;

  if (editId) {
    const room = roomsCache.find((item) => String(item.id) === String(editId));
    if (room) openRoomModal(room);
  }

  if (deleteId) {
    if (!confirm("Delete this room? This is allowed only if there is no active booking.")) return;
    try {
      await request(`${API}/rooms/${deleteId}`, { method: "DELETE" });
      showToast("Room deleted successfully");
      await refreshAll();
    } catch (error) {
      showToast(error.message, "error");
    }
  }
});

document.getElementById("room-search").addEventListener("input", () => {
  loadRooms().catch((error) => showToast(error.message, "error"));
});
document.getElementById("room-type-filter").addEventListener("change", () => {
  loadRooms().catch((error) => showToast(error.message, "error"));
});

document.getElementById("search-form").addEventListener("submit", async (event) => {
  event.preventDefault();
  const type = document.getElementById("search-type").value;
  const checkIn = document.getElementById("search-checkin").value;
  const checkOut = document.getElementById("search-checkout").value;

  try {
    const params = new URLSearchParams({ type, checkIn, checkOut });
    const result = await request(`${API}/rooms/search?${params.toString()}`);
    const container = document.getElementById("search-results");

    if (!result.data.length) {
      container.innerHTML = "<p>No available rooms for the selected dates.</p>";
      return;
    }

    container.innerHTML = result.data.map((room) => `
      <article class="room-card search-room-card">
        <div class="search-room-img-wrap">
          <img src="${getRoomImage(room.room_type)}" alt="${room.room_type}" />
          <span class="room-type-badge">${room.room_type}</span>
        </div>
        <div class="search-room-body">
          <div class="search-room-title-row">
            <h4>Room ${room.room_number}</h4>
            <span class="search-room-price"><strong>${formatINR(room.price)}</strong> / night</span>
          </div>
          <div class="search-room-calc">
            <span>📅 <strong>${room.number_of_nights}</strong> night(s)</span>
            <span>Total: <strong class="total-highlight">${formatINR(room.total_amount)}</strong></span>
          </div>
          <button class="btn primary full-width" data-book-room="${room.id}" data-checkin="${checkIn}" data-checkout="${checkOut}">
            Book Room ${room.room_number}
          </button>
        </div>
      </article>
    `).join("");
  } catch (error) {
    showToast(error.message, "error");
  }
});

document.getElementById("search-results").addEventListener("click", (event) => {
  const roomId = event.target.dataset.bookRoom;
  if (!roomId) return;
  selectedSearchRoomId = roomId;
  document.getElementById("booking-room").value = roomId;
  document.getElementById("booking-checkin").value = event.target.dataset.checkin;
  document.getElementById("booking-checkout").value = event.target.dataset.checkout;
  updateBookingSummary();
  switchSection("book");
});

function updateBookingSummary() {
  const roomId = document.getElementById("booking-room").value;
  const checkIn = document.getElementById("booking-checkin").value;
  const checkOut = document.getElementById("booking-checkout").value;
  const room = roomsCache.find((item) => String(item.id) === String(roomId));
  const nights = nightsBetween(checkIn, checkOut);
  const summary = document.getElementById("booking-summary");

  if (!room || nights <= 0) {
    summary.textContent = "Select a room and valid dates to see nights and total amount.";
    return;
  }

  const total = nights * room.price;
  summary.textContent = `${nights} night(s) × ${formatINR(room.price)} = ${formatINR(total)}`;
}

["booking-room", "booking-checkin", "booking-checkout"].forEach((id) => {
  document.getElementById(id).addEventListener("change", updateBookingSummary);
});

document.getElementById("booking-form").addEventListener("submit", async (event) => {
  event.preventDefault();
  const payload = {
    guest_name: document.getElementById("guest-name").value.trim(),
    guest_email: document.getElementById("guest-email").value.trim(),
    guest_phone: document.getElementById("guest-phone").value.trim(),
    room_id: Number(document.getElementById("booking-room").value),
    check_in: document.getElementById("booking-checkin").value,
    check_out: document.getElementById("booking-checkout").value
  };

  const nights = nightsBetween(payload.check_in, payload.check_out);
  if (nights <= 0) {
    showToast("Check-out date must be after check-in date", "error");
    return;
  }

  const room = roomsCache.find((item) => item.id === payload.room_id);
  const total = room ? nights * room.price : 0;
  if (!confirm(`Confirm booking for ${nights} night(s)? Total amount: ${formatINR(total)}`)) {
    return;
  }

  try {
    await request(`${API}/bookings`, { method: "POST", body: JSON.stringify(payload) });
    showToast("Room booked successfully");
    document.getElementById("booking-form").reset();
    selectedSearchRoomId = null;
    await refreshAll();
    switchSection("bookings");
  } catch (error) {
    showToast(error.message, "error");
  }
});

async function loadBookings() {
  const q = document.getElementById("booking-search").value.trim();
  const params = new URLSearchParams();
  if (q) params.set("q", q);
  const result = await request(`${API}/bookings?${params.toString()}`);
  renderBookings(result.data);
}

function renderBookings(bookings) {
  const tbody = document.getElementById("bookings-table");
  tbody.innerHTML = bookings.map((booking) => `
    <tr>
      <td>${booking.id}</td>
      <td>${booking.guest_name}</td>
      <td>${booking.guest_email}</td>
      <td>${booking.guest_phone}</td>
      <td>${booking.room_number}</td>
      <td>${booking.room_type}</td>
      <td>${booking.check_in}</td>
      <td>${booking.check_out}</td>
      <td><span class="status-pill status-${booking.status}">${booking.status}</span></td>
      <td class="actions">
        <button class="btn small" data-view="${booking.id}">View</button>
        ${booking.status === "Confirmed"
          ? `<button class="btn small danger" data-cancel="${booking.id}">Cancel</button>`
          : ""}
      </td>
    </tr>
  `).join("") || `<tr><td colspan="10">No bookings found</td></tr>`;
}

document.getElementById("booking-search").addEventListener("input", () => {
  loadBookings().catch((error) => showToast(error.message, "error"));
});

document.getElementById("bookings-table").addEventListener("click", async (event) => {
  const viewId = event.target.dataset.view;
  const cancelId = event.target.dataset.cancel;

  if (viewId) {
    try {
      const result = await request(`${API}/bookings/${viewId}`);
      const booking = result.data;
      document.getElementById("view-booking-body").innerHTML = `
        <p><strong>Booking ID:</strong> ${booking.id}</p>
        <p><strong>Guest:</strong> ${booking.guest_name}</p>
        <p><strong>Email:</strong> ${booking.guest_email}</p>
        <p><strong>Phone:</strong> ${booking.guest_phone}</p>
        <p><strong>Room:</strong> ${booking.room_number} (${booking.room_type})</p>
        <p><strong>Dates:</strong> ${booking.check_in} to ${booking.check_out}</p>
        <p><strong>Nights:</strong> ${booking.number_of_nights}</p>
        <p><strong>Total:</strong> ${formatINR(booking.total_amount)}</p>
        <p><strong>Status:</strong> ${booking.status}</p>
      `;
      document.getElementById("view-modal").classList.remove("hidden");
    } catch (error) {
      showToast(error.message, "error");
    }
  }

  if (cancelId) {
    if (!confirm("Cancel this booking? The record will be kept in history.")) return;
    try {
      await request(`${API}/bookings/${cancelId}/cancel`, { method: "POST" });
      showToast("Booking cancelled successfully");
      await refreshAll();
    } catch (error) {
      showToast(error.message, "error");
    }
  }
});

document.getElementById("view-close").addEventListener("click", () => {
  document.getElementById("view-modal").classList.add("hidden");
});

// Hero & Dashboard Navigation Shortcuts
const heroBtnSearch = document.getElementById("hero-btn-search");
if (heroBtnSearch) heroBtnSearch.addEventListener("click", () => switchSection("search"));

const heroBtnGallery = document.getElementById("hero-btn-gallery");
if (heroBtnGallery) heroBtnGallery.addEventListener("click", () => switchSection("gallery"));

const viewGalleryBtn = document.getElementById("view-gallery-btn");
if (viewGalleryBtn) viewGalleryBtn.addEventListener("click", () => switchSection("gallery"));

const viewRoomsBtn = document.getElementById("view-rooms-btn");
if (viewRoomsBtn) viewRoomsBtn.addEventListener("click", () => switchSection("rooms"));

// Quick Book from Dashboard Room Showcase
document.querySelectorAll("[data-quick-type]").forEach((btn) => {
  btn.addEventListener("click", () => {
    const type = btn.dataset.quickType;
    const searchTypeSelect = document.getElementById("search-type");
    if (searchTypeSelect) searchTypeSelect.value = type;
    switchSection("search");
    showToast(`Showing availability search for ${type} Room`);
  });
});

// Gallery Filter Buttons
document.querySelectorAll(".gallery-filter-btn").forEach((btn) => {
  btn.addEventListener("click", () => {
    document.querySelectorAll(".gallery-filter-btn").forEach((b) => b.classList.remove("active"));
    btn.classList.add("active");
    const filter = btn.dataset.filter;
    document.querySelectorAll(".gallery-item").forEach((item) => {
      if (filter === "all" || item.dataset.category === filter) {
        item.style.display = "block";
      } else {
        item.style.display = "none";
      }
    });
  });
});

async function refreshAll() {
  await Promise.all([loadDashboard(), loadRooms(), loadBookings()]);
}

refreshAll().catch((error) => showToast(error.message, "error"));

